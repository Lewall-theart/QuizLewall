﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuizIT.Service.Models
{
    public class ExportHistory
    {
        public string QuestionContent { get; set; }
        public string AnswerSelect { get; set; }
        public string Result { get; set; }
    }
}
