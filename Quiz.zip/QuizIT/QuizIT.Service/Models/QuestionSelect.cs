﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuizIT.Service.Models
{
    public class QuestionSelect
    {
        public int QuestionId { get; set; }
        public string AnswerSelect { get; set; }
    }
}
